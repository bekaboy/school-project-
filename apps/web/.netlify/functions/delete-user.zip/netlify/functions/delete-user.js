var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/delete-user.ts
var delete_user_exports = {};
__export(delete_user_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(delete_user_exports);
var handler = async (event, _context) => {
  const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }), headers };
  }
  try {
    const { email } = JSON.parse(event.body ?? "{}");
    if (!email) {
      return { statusCode: 400, body: JSON.stringify({ error: "Email is required" }), headers };
    }
    const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !serviceRoleKey) {
      return { statusCode: 500, body: JSON.stringify({ error: "Server configuration error" }), headers };
    }
    const listRes = await fetch(
      `${supabaseUrl}/auth/v1/admin/users?email=${encodeURIComponent(email)}`,
      {
        headers: {
          apikey: serviceRoleKey,
          Authorization: `Bearer ${serviceRoleKey}`
        }
      }
    );
    const users = await listRes.json();
    const found = Array.isArray(users) ? users.find((u) => u.email === email) : null;
    if (!found?.id) {
      return { statusCode: 404, body: JSON.stringify({ error: "Auth user not found" }), headers };
    }
    const delRes = await fetch(`${supabaseUrl}/auth/v1/admin/users/${found.id}`, {
      method: "DELETE",
      headers: {
        apikey: serviceRoleKey,
        Authorization: `Bearer ${serviceRoleKey}`
      }
    });
    if (!delRes.ok) {
      const err = await delRes.json();
      return { statusCode: 400, body: JSON.stringify({ error: err.msg || err.error || "Failed to delete auth user" }), headers };
    }
    return {
      statusCode: 200,
      body: JSON.stringify({ success: true }),
      headers
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Internal server error";
    return { statusCode: 500, body: JSON.stringify({ error: message }), headers };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
